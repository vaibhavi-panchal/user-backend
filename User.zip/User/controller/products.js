 const getAllProducts = async(req, res) => {
    res.status(200).json({ msg:"I get All products" });
 };

 const getAllProductsTesting = async(req, res) => {
    res.status(200).json({ msg:"I get AllProductsTesting" });
 };

 module.exports = {getAllproducts, getAllproductsTesting};