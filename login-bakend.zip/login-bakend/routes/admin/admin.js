let express = require('express');
let bodyparser = require("body-parser");
let router = express.Router();

router.post("admin/login",(req,res)=>{
    let body = req.body;
    let status = "";if(bod)
})