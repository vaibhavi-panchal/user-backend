var express = require('express');

const router = express.Router();

var userController = require('../userController');

router.route('/User/getAll').get(userController.getDataConntrollerfn);

router.route('/User/create').post(userController.createUserControllerFn);



router.route('/User/update/:id').patch(userController.updateUserController);

router.route('/User/delete/:id').delete(userController.deleteUserController);

module.exports = router;