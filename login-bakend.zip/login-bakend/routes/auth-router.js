const router = require('express').Router();
const User = require('../models/user');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');



router.post('/Register', (req, res) => {
    console.log("request is", req.body)
    bcrypt.hash(req.body.password, 10, (err, pHash) => {
        if (err) {
            return res.json({ success: false, messege: "Hash error !" })
        } else {
            const user = new User({
                username: req.body.username,
                name: req.body.name,
                password: pHash,
                email: req.body.email,
            })

            user.save()
                .then((_) => {
                    res.json({ success: true, messege: "Account has been created" })
                })
                .catch((err) => {
                    console.log("error in ", err)
                    if (err.code === 11000) {
                        return res.json({ success: false, message: "username is required" })
                    }
                    res.json({ success: false, messege: "Authentication Failed !!" })
                })
        }
    });
}
)

router.post('/Login', (req, res) => {
    console.log("request is", req.body)
    User.find({ username: req.body.username }).exec().then((result) => {
        if (result.length < 1) {
            return res.json({ error: "error", message: "User not found !!", trace: new Error().stack })
        }
        console.log("user find");
        const user = result[0];
        bcrypt.compare(req.body.password, user.password, (_err, _ret) => {
            if (_err) {
                return res.json({ error: err, message: "Login Faiure.", trace: new Error().stack })
            }
            if (_ret) {
                return res.json({ success: true, message: "Login Successful!!." })
            } else {
                return res.json({ error: "true", message: "Password did not match.", trace: new Error().stack })
            }
        })
        console.log("password comparison");
    }).catch(_err => {
        res.json({ err: err, message: "Authentication failed!", trace: new Error().stack })
    })
})
router.get('/profile', (req, res) => {
    const userId = req.userData;
    User.findById(userId).exec().then((result) => {
        result.json({ success: true, data: result })

    }).catch(_err => {
        res.json({ success: false, message: "server error" })
    })
})
module.exports = router


