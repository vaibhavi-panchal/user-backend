let mongoose = require("mongoose");
let Schema = mongoose.Schema;
let schema = new Schema(
    {
        pcid: { type: String, required: true },
        srno: { type: Number, required: true },
        name: { type: String, required: true },
        Height: { type: Number, required: true },
        weight: { type: Number, required: true },
        wrist: { type: Number, required: true },
        Soulder: { type: Number, required: true },
        chest: { type: Number, required: true },
        weist: { type: Number, required: true },

    }
);
let Measurment = mongoose.model("measurements", schema);
module.exports = Measurment;