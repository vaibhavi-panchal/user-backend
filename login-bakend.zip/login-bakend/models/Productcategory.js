let express = require("express");
let bodyparser = require("body-parser");
let productcategory = require("../models/Productcategory");
let fs = require("fs");

let router = express.Router();


router.post("/list", async (req, res) => {
    let body = req.body;
    let productcategory = await productcategory.findById(body.data.id);
    res.end(JSON.stringify({ status: "success", data: productcategory }));
});

router.post("/get", async (req, res) => {
    let body = req.body;
    let productcategory = await productcategory.findById(body.data.id);
    res.end(JSON.stringify({ status: "success", data: productcategory }));
});

router.post("/delete", async (req, res) => {
    let body = req.body;
    let productcategory = await productcategory.findById(body.data.id);
    res.end(JSON.stringify({ status: "success", data: productcategory }));
});




module.exports = router;
