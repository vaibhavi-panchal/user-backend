const express = require('express');
const bodyParser = require('body-parser');

const app = express();

const port = process.env.port || 8080 //this is use for server port//
const authRoute = require('./routes/auth-router');
const mongoose = require('mongoose');
const cors = require('cors')
// const { bodyParser } = require('json-server');

mongoose.connect("mongodb://127.0.0.1:27017/abc", (err)=>{
    if(err){
        console.log("error in connection",err);
        console.log("Database is not connected!");
    }else{
        console.log("DB is connected.....");
    }
});



app.use(bodyParser.json());
app.use(cors())
app.use('/auth',authRoute);
app.get('/', (req, res) =>{
    res.send("Welcome to my page 0")
})

app.listen(port, ()=>{
    console.log("node server is connected:", 8080)
})