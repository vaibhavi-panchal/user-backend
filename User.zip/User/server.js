var express = require('express');
var app = express();
var http = require('http');
var mongoose = require('mongoose');
var routes = require('./routes/routes');
const cors=require("cors");
const { Console } = require('console');




app.use(cors());
app.use(express.json());
app.use(routes);



mongoose.connect("mongodb://localhost:27017/abc",{
    useNewUrlParser:true,
    useUnifiedTopology:true
},(err)=>{
    if(err)
    {
        console.log("connected to db")
    }
    else
    {
        console.log("error")
    }
});

//SCHEMA

// const schema={
//     name:string,
//     email:string,
//     id:number
// }
// const monmodel=mongoose.model("NEWCOL",sch);


app.get('/', (req, res) => {
  res.end('Hello World!');
});


//POST
app.post("/login_ex",async(req,res)=>{
    console.log("inside post function");

    // const data=new monmodel ({
    //     name:req.body.name.string,
    //     email:req.body.email.string,
    //     id:req.body.id.number
    // });

    // const val=await data.save();
    // res.json(val);
    let data = req.body;
    let output = "JJ";
    res.send('Data Received: ' + JSON.stringify(output));
})

app.listen(8000,()=>{
    console.log("on port 8000")
})