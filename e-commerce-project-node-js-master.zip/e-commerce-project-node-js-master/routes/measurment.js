let express = require("express");
let bodyparser = require("body-parser");
let Measurment = require("../models/Measurment");


let router = express.Router();

router.post("/Measurment", async (req, res) => {
    try {
        let body = req.body;
        let measurment = new Measurment();

        let measurments = await Measurment.find({ name: body.data.name });
        if (measurments.length != 0) {
            res.end(JSON.stringify({ status: "failed", data: "pcid is alreadt exist" }));
        }
        measurments = await Measurment.find({ srno: body.data.srno });
        if (measurments.length != 0) {
            res.end(JSON.stringify({ status: "failed", data: "Srno already exist" }));
        }
        measurment.pcid = body.data.pcid;
        measurment.srno = body.data.srno;
        measurment.name = body.data.name;
        measurment.Height = body.data.height;
        measurment.weight = body.data.weight;
        measurment.wrist = body.data.wrist;
        measurment.shoulder = body.data.shoulder;
        measurment.chest = body.data.chest;
        measurment.weist = body.data.weist;
        measurment.save().then(result => {
            res.end(JSON.stringify({ status: "success", data: result }));
        }, err => {
            res.end(JSON.stringify({ status: "failed", data: err }));
        });
    }
    catch {
        res.end(JSON.stringify({ status: "failed", data: "Something went wrong" }));
    }
});


router.post("/measurments", async (req, res) => {
    try {
        let body = req.body;
        let measurments = await Measurment.find({ pcid: body.data.pcid });
        res.end(JSON.stringify({ status: "success", data: measurments }));
    }
    catch {
        res.end(JSON.stringify({ status: "failed", data: "Something went wrong" }));
    }
});

module.exports = router;