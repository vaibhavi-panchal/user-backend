var mongoose = require('mongoose');
var Schema = mongoose.Schema;
 
var userSchema = new mongoose.Schema({
 
    firstname: {
        type: String,
        required: true,
        unique:true
    },
    lastname: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
    },
    mobile_number: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    },
});
 
module.exports = mongoose.model('customers', userSchema);